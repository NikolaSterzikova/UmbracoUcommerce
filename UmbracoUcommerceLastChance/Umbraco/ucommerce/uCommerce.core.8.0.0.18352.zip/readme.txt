  _    _                                                                    
 | |  | |                                                                   
 | |  | |   ___    ___    _ __ ___    _ __ ___     ___   _ __    ___    ___ 
 | |  | |  / __|  / _ \  | '_ ` _ \  | '_ ` _ \   / _ \ | '__|  / __|  / _ \
 | |__| | | (__  | (_) | | | | | | | | | | | | | |  __/ | |    | (__  |  __/
  \____/   \___|  \___/  |_| |_| |_| |_| |_| |_|  \___| |_|     \___|  \___| 

=============================================================================
Thank you for installing Ucommerce! 

Please read this. This is not your typical legal mumbo jumbo. 

Need help with a client case? 
If you need help addressing a client case with specific e-commerce requirements we're here to help. 

Usually you need to know where you can go with the standard features out of the box and where you need developers to create new features. 

We can help you in this process by going through your requirements with an eye to what Ucommerce provides out of the box. 
Send us your requirements today at sales-support@ucommerce.net 

Please report any bugs or feature requests on our feedback forum at http://ucommerce.uservoice.com.
============================================================================= 